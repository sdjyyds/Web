/*
console.log("Hello, world!"); // 输出文本到浏览器的控制台
alert("这是一个警告框!"); // 在浏览器中弹出一个警告对话框
document.write("这个文本将被写入到 HTML 页面中"); // 向页面中添加文本——会覆盖原网页
    <p id="output">这里将显示 JavaScript 生成的文本。</p>
        // 通过 JavaScript 修改指定元素的内容
        document.getElementById("output").innerHTML = "Hello, JavaScript!";
        NaN非数字特殊值，与任何值==都不相等，number.isNaN(NaN)可以判断它是不是NaN
var即使所有的变量
创建数组——new Array(size)表示创建，new Array(元素1，元素2，……);new Obj=[元素1,元素2,元素3,……];
var nums=new Array(20,33,1,65,43,15)document.write("排序前："+nums);遍历for(i int nums) nums[i]

function fun(var1,var2) document.write(arguments.length)——函数的内置对象，调用方法即可查看传入参数个数;
无返回，直接是undefined的类型
var Car=new Object;Car.color="red";car.showColor1=function(){document.write()};car.showColor1();构建对象
// 使用构造函数创建一个对象模板
function Person(firstName, lastName, age) {
  this.firstName = firstName;
  this.lastName = lastName;
  this.age = age;
  this.greet = function() {
    console.log("Hello, " + this.firstName + " " + this.lastName);
  };
}

// 使用构造函数创建一个对象实例
const person1 = new Person("John", "Doe", 30);
const person2 = new Person("Jane", "Smith", 25);

// 访问对象属性和方法
console.log(person1.firstName); // 输出 "John"
console.log(person2.age); // 输出 25
person1.greet(); // 调用对象方法，输出 "Hello, John Doe"

// 使用构造函数创建一个对象模板
function Person(firstName, lastName, age) {
  this.firstName = firstName;
  this.lastName = lastName;
  this.age = age;
  this.greet = function() {
    console.log("Hello, " + this.firstName + " " + this.lastName);
  };
}

// 使用构造函数创建一个对象实例
const person1 = new Person("John", "Doe", 30);
const person2 = new Person("Jane", "Smith", 25);

// 访问对象属性和方法
console.log(person1.firstName); // 输出 "John"
console.log(person2.age); // 输出 25
person1.greet(); // 调用对象方法，输出 "Hello, John Doe"


javaScript事件处理
id=div1;
var div1=document.getElementById("div1");
div1.addEventListener("click",function(){},true);
onclur失去焦点=(语句or函数)onkeyup=(照旧)
onsubmit=() onfocus=() onsubmit=(),action=()

修改html的元素的值方法
   const paragraph = document.getElementById("myParagraph");
            paragraph.innerHTML = "这是新的文本 <strong>加粗</strong>";
  const paragraph = document.getElementById("myParagraph");
            paragraph.textContent = "这是新的文本 <strong>不加粗</strong>";
    const paragraph = document.getElementById("myParagraph");
            paragraph.innerText = "这是新的文本 <strong>不加粗</strong>";    
*/

function b() {
  alert("欢迎来到我的网站");
}
function a() {
  document.write("恭喜你，你的信息已被我获取");
  window.location.href = "https://www.baidu.com";
}
function pan(){
  var div1=document.getElementById("submit1");
  div1.addEventListener("click", function (event) {
    event.preventDefault();
    var error_message = document.getElementById("error-message");
    var name=document.getElementById("username").value;
    var testname=/^[0-9a-z_A-Z]{5,20}$/;
    var namel=name.length;
    if(!testname.test(name))
    {
        if(!name) {alert("请输入用户名！");return;}
        else if(namel<5) {error_message.innerHTML="输入名的长度不能小于5！";return;} 
        else if(namel>20) {error_message.innerHTML="输入名的长度不能大于20！"; return;}
        else {error_message.innerHTML="输入的格式不合法！"; return;}
    }
    var password=document.getElementById("password").value;
    var testpassword=/^[a-zA-Z0-9][0-9a-z_A-Z]{9,19}$/;
    var passwordl=password.length;
    if(!testpassword.test(password))
    {
      if(!password) {alert("请输入密码！");return;}
      else if(passwordl<10) {error_message.innerHTML="输入密码的长度不能小于10！";return;}
      else if(passwordl>20) {error_message.innerHTML="输入名的长度不能大于20！";return;}
      else {error_message.innerHTML="输入的格式不合法！";return;}
    }
    error_message.innerHTML="";
  },true);
}
