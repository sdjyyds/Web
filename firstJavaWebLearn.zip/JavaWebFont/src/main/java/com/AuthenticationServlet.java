package com;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/servlet-url")
public class AuthenticationServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // 获取前端提交的用户名和密码
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // 在此进行与数据库的交互，验证用户名和密码是否合法
        // 假设数据库操作类为 DatabaseOperations

        if (DatabaseOperations.authenticate(username, password)) {
            // 用户验证成功
            response.sendRedirect("Hello");
        } else {
            // 用户验证失败
            out.println("认证失败，请检查用户名和密码");
        }
    }
}
