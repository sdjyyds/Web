package com;

import java.io.*;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
 * Servlet implementation class Servlet1
 */
@WebServlet("/Servlet1")
public class Servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
    String []username= {"钟细慧","刘帅"};
    String []userPassword={"zxh666","lsyyds"};
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		response.setContentType("text/html;charset=UTF-8");
		HttpSession session = request.getSession();
		session.setAttribute("visited", true);
		//账户： 钟细慧 密码：zxh666 刘帅 密码：liushuaiyyds
		String username=request.getParameter("username");
		String userpassword=request.getParameter("userpassword");
		if(Check(username,userpassword))
		{
			System.out.println(username);
			System.out.println(userpassword);
			// 在Servlet A 中设置信息到会话
			session.setAttribute("username", username);
			response.sendRedirect("Hello");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		ServletContext context = this.getServletContext();
		InputStream in = context.getResourceAsStream("/WEB-INF/classes/config.properties");
		Properties pros = new Properties();
		pros.load(in);
		out.println(pros.getProperty("Company"));
		out.println(pros.getProperty("Address"));
	}
	
	private boolean Check(String username,String userpassword)
	{
		for(var i:this.username)
			if(username.equals(i))
			{
				for(var j:this.userPassword)
					if(userpassword.equals(j)) return true;
			}
		return false;
	}
}
