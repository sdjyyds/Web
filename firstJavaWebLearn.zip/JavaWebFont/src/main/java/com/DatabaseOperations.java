package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DatabaseOperations {
    private static final String DB_URL = "jdbc:postgresql://localhost:5432/users";
    private static final String DB_USER = "postgres";
    private static final String DB_PASSWORD = "abc123";

    public static Connection getConnection() {
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }
    void way()
    {
    	try (Connection connection = getConnection()) {
    		String sql="SELECT * FROM users";
    		System.out.println(sql);
    	}catch(Exception e) {}
    }
    public static boolean authenticate(String username, String password) {
        try (Connection connection = getConnection()) {
            String sql = "SELECT user_name,user_password FROM users WHERE user_name = ? AND user_password = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            ResultSet resultSet = preparedStatement.executeQuery();
            return resultSet.next(); // 如果存在匹配的记录，返回true；否则返回false
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public static void main(String []args)
    {
    	DatabaseOperations a=new DatabaseOperations();
    	a.way();
    }
}

