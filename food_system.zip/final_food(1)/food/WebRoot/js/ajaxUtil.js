function createRequest() {
	let request;
	let reqs = [function(){return new XMLHttpRequest();},
				function(){return new ActiveXObject("Msxml2.XMLHTTP");},
				function(){return new ActiveXObject("Msxml3.XMLHTTP");}];
	
	for(let i = 0;i < reqs.length;i++) {
		try {
			request = reqs[i]();
			break;
		}catch(e) {
			continue;
		}
		
	}
	
	return request;
}
/*
* method 请求方式(get  post)
* uri 请求的映射uri资源
* parmas 传给后端的参数
* fun 传入的自定义回调函数
*/
function sendAjax(method,uri,params,fun) {
	let request = createRequest();
	request.open(method,uri);
	
	request.onreadystatechange = function() {
		if(request.readyState == 4) {
			fun(request);
		}
	};
	if(method.toLowerCase() == 'post') {
		request.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	}
	if(method.toLowerCase() == 'post' && params != null) {
		request.send(params);
	}else {
		request.send(null);
	}
	
}