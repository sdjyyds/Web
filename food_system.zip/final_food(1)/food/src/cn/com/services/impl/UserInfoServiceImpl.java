package cn.com.services.impl;

import java.sql.Connection;
import java.sql.SQLException;

import cn.com.dao.UserInfoDAOInf;
import cn.com.dao.impl.UserInfoDAOImpl;
import cn.com.db.DBUtil;
import cn.com.pojo.UserInfo;
import cn.com.services.UserInfoServiceInf;

/*
 * ʵ�����û��ķ����Ľӿ�
 */
public class UserInfoServiceImpl implements UserInfoServiceInf {
	private UserInfoDAOInf dao;
	
	/*
	 * ��ʼ����Ҫ�õ��Ĳ���
	 */
	public UserInfoServiceImpl() {
		dao = new UserInfoDAOImpl();
	}
	
	@Override
	/*
	 * �����û������������dao����ж��û������������ȷ��
	 */
	public boolean validateByNoAndPwd(int userNo, String userPwd) {
		// TODO Auto-generated method stub
		Connection conn = null;
		boolean bool = false;
		try {
			conn = DBUtil.getConn();
			conn.setAutoCommit(false);
			bool = dao.validateByNoAndPwd(conn, userNo, userPwd);
			if(bool) {
				//�û����޸����
				
				conn.commit();
				return bool;
			}
			conn.rollback();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return bool;
	}

	/*
	 * �����û�������dao����÷����õ��û�����ϸ.
	 */
	@Override
	public UserInfo getUserInfoByNo(int userNo) {
		// TODO Auto-generated method stub
		Connection conn = null;
		UserInfo u = null;
		try {
			conn = DBUtil.getConn();
			conn.setAutoCommit(false);
			u = dao.getUserInfoByNo(conn, userNo);
			if(u != null) {
				conn.commit();
			}else {
				conn.rollback();
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return u;
	}
	
	@Override
	/*
	 * �����û������ж��Ƿ���ȷ
	 */
	public boolean validateByNo(int userNo) {
		// TODO Auto-generated method stub
		Connection conn = null;
		boolean bool = false;
		try {
			conn = DBUtil.getConn();
			conn.setAutoCommit(false);
			bool = dao.validateByNo(conn, userNo);
			if(bool) {
				
				conn.commit();
				return bool;
			}
			conn.rollback();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return bool;
	}
	
	@Override
	/*
	 * ����dao��ķ�������ָ���û�����Ϣ���뵽����
	 */
	public boolean insertIntoUsers(UserInfo user1) {
		// TODO Auto-generated method stub
		Connection conn = null;
		boolean bool = false;
		try {
			  conn = DBUtil.getConn();
			  conn.setAutoCommit(false);
			  user1.setUid(dao.getMaxUId(conn));
			  bool = dao.insertIntoUsers(conn, user1);
			  if(bool) {
					
					conn.commit();
					return bool;
				}
				conn.rollback();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				try {
					conn.rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
			}
		
	}
		return false;	
		}

	@Override
	public int getMaxUId() {
		// TODO Auto-generated method stub
		Connection conn = null;
		int UId = 0;
		try {
			  conn = DBUtil.getConn();
			  UId = dao.getMaxUId(conn);

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return UId;
	}
}
