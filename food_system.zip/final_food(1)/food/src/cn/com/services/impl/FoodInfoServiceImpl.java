package cn.com.services.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import cn.com.dao.FoodInfoDAOInf;
import cn.com.dao.impl.FoodInfoDAOImpl;
import cn.com.dao.ShoppingCartInf;
import cn.com.dao.impl.ShoppingCartInfoImpl;
import cn.com.db.DBUtil;
import cn.com.pojo.FoodInfo;
import cn.com.services.FoodInfoServiceInf;
import cn.com.pojo.shoppingCartInfo;

/*
 * ʵ��ʳƷ�ķ�����Ľӿ�
 */
public class FoodInfoServiceImpl implements FoodInfoServiceInf {
	private FoodInfoDAOInf dao;
	private ShoppingCartInf shopping;
	
	/*
	 *��ʼ����Ҫ�õ����� 
	 */
	public FoodInfoServiceImpl() {
		dao = new FoodInfoDAOImpl();
		shopping = new ShoppingCartInfoImpl();
	}
	
	@Override
	/*
	 * ʵ�ֲ���������Ʒ�Ĺ���
	 */
	public List<FoodInfo> searchFoodAllService() {
		// TODO Auto-generated method stub
		Connection conn = null;
		List<FoodInfo> list = null;
		try {
			conn = DBUtil.getConn();
			conn.setAutoCommit(false);
			
			list = dao.getAllFoodInfo(conn);
			conn.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}finally {
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return list;
	}

	/*
	 * ʵ�ֲ��Ҷ�ӦʳƷ��Ϣ�Ĺ���
	 */
	public FoodInfo searchFoodByIdService(int foodId) {
		// TODO Auto-generated method stub
		Connection conn = null;
		FoodInfo fib = null;
		try {
			conn = DBUtil.getConn();
			conn.setAutoCommit(false);
			
			fib = dao.getFoodInfoById(conn, foodId);
			conn.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}finally {
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return fib;
	}
	
	/*
	 * �������ﳵ��ʵ�ֹ��ﳵ��Ӧ������1��������Ǹ����û�����ʳƷid��ȷ���ù��ﳵ�����͵ġ�
	 */
	@Override
	public boolean changeGoods(int foodId,int uId) {
		// TODO Auto-generated method stub
		Connection conn = null;
		FoodInfo fib = null;
		int ctId = -1;
		boolean flag = false;
		try {
			conn = DBUtil.getConn();
			conn.setAutoCommit(false);
			
		    flag = dao.changeGoods(conn, foodId);
		    ctId = shopping.getTrueShoppingCart(conn, uId, foodId); 
		    if(ctId != -1)
		    {
		    	shopping.changeShoppingCart(conn,ctId);
		    }
		    else
		    {
		    	shoppingCartInfo shoppingCart = new shoppingCartInfo();
		    	shoppingCart.setgId(foodId);
		    	shoppingCart.setuId(uId);
		    	shoppingCart.setCtId(shopping.getMaxctId(conn));
		    	shopping.insertIntoShoppingCart(conn, shoppingCart);
		    }
		    
			conn.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				return false;
			}
		}finally {
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		if(flag) return true;
		else return false;
	}	

}
