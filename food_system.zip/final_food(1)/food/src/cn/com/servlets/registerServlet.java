package cn.com.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.com.actions.Action;
import cn.com.actions.ActionFactory;
import cn.com.dao.UserInfoDAOInf;
import cn.com.dao.impl.UserInfoDAOImpl;

/*
 *���ע���servelt�� 
 */
public class registerServlet extends HttpServlet{
	
	/*
	 * ���ö�Ӧ�ķ���.
	 */
	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		String type = request.getParameter("type");
		Action action = ActionFactory.getAction(type);
		action.execute(request, response);
	}
}
