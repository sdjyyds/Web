package cn.com.actions;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cn.com.dao.impl.FoodInfoDAOImpl;
import cn.com.dao.impl.ShoppingCartInfoImpl;
import cn.com.dao.impl.UserInfoDAOImpl;
import cn.com.db.DBUtil;
import cn.com.pojo.FoodInfo;
import cn.com.pojo.UserInfo;
import cn.com.pojo.shoppingCartInfo;

public class showAllShoppingCart extends Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		// TODO Auto-generated method stub
		try {
			Connection  conn = DBUtil.getConn();
			// ��Servlet�д������ȡ�Ự
			HttpSession session = request.getSession();
			// �ڻỰ�д洢��Ϣ
//			UserInfoDAOImpl user = new UserInfoDAOImpl();
//			UserInfo u = user.getUserInfoByNo(conn, Integer.parseInt(request.getParameter("loginName")));
//			session.setAttribute("user",u);
			ShoppingCartInfoImpl shop = new ShoppingCartInfoImpl();
			UserInfo  u = (UserInfo) session.getAttribute("uInfo");
			List<FoodInfo> foods = new ArrayList<>();
 			List<shoppingCartInfo> s =  shop.getAllshoppingCartInfo(conn, u.getUid());
 			
			request.setAttribute("ShoppingCart", s);
			FoodInfoDAOImpl f = new FoodInfoDAOImpl();
			
			for (int i = 0; i < s.size(); i++) {
			    shoppingCartInfo item = s.get(i);
			    foods.add( f.getFoodInfoById(conn,item.getgId()));
			    // �����ﴦ��ÿ�� shoppingCartInfo ���� (item)
			}
			session.setAttribute("food",foods);
			
			request.getRequestDispatcher("orderitem.jsp").forward(request, response);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
