package cn.com.actions;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.com.dao.impl.FoodInfoDAOImpl;
import cn.com.db.DBUtil;
import cn.com.pojo.FoodInfo;

/*
 * ������ǽ���Ʒ����ϸ��ʾ����
 */

public class showGoodsDetails extends Action{

	@Override
	/*
	 * ͨ��ֱ�ӵ���dao����ʵ�ֲ�ѯ��Ʒ����ϸ��Ϣ��Ȼ����ת��չʾ��Ʒ��Ϣ�Ľ��档
	 */
	
	public void execute(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		
		int gid = Integer.parseInt(request.getParameter("goods_id"));
		try {
			Connection  conn = DBUtil.getConn();
			FoodInfoDAOImpl food_show = new FoodInfoDAOImpl();
			FoodInfo food = food_show.getFoodInfoById(conn, gid);
			request.setAttribute("food", food);
			RequestDispatcher dispatcher = request.getRequestDispatcher("show.jsp");
		    dispatcher.forward(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
