package cn.com.actions;

/*
 * ����Ĺ�����ͨ����дURL���λ����ر����ķ�ʽ���Σ�ͨ��type����Ӧ��ǩƥ�䣬������Ӧ����
 */
public abstract class ActionFactory {
	
	public static final String LOGIN = "login";
	public static final String VALIDATE = "validate";
	public static final String SHOWGOODSDETAILS = "showgoodsdetails";
	public static final String SHOWALLGOODS = "showAllGoods";
	public static final String GOODSCHANGE = "goodsChange";
	public static final String INSERTINTOUSERS = "insertIntoUsers";
	public static final String SHOWALLSHOPPINGCART = "showAllShoppingCart";
	private ActionFactory() {
		
	}
/*
 * typeƥ�������õĳ���	
 */
	public static Action getAction(String type) {
		Action action = null;
		
		if(type.equals(LOGIN)) {
			action = new LoginAction();
		}else if(type.equals(VALIDATE)) {
			action = new ValidateByNoAction();
		}else if(type.equals(SHOWGOODSDETAILS)){
			action = new showGoodsDetails();
		}else if(type.equals(SHOWALLGOODS)){
			action = new showAllGoods();
		}else if(type.equals(GOODSCHANGE)){
			action = new goodsChange();
		}else if(type.equals(INSERTINTOUSERS)){
			action = new InsertIntoUsers();
		}else if(type.equals(SHOWALLSHOPPINGCART)){
			action = new showAllShoppingCart();
		}
		return action;
	}
}
