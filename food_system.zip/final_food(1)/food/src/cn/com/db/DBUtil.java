package cn.com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *ʵ�����ݿ�����ӣ������������Լ��ͷ���Դ���ܡ�
 */
public abstract class DBUtil {
	private DBUtil() {
		
	}
	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * �õ����Ӷ���
	 * @return 
	 * @throws SQLException
	 */
	public static Connection getConn() throws SQLException {
		Connection conn = null;
		
		conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/manage_restaurant?useSSL=false&serverTimezone=UTC", "root", "abc123");
		return conn;
	}
	
	/*
	 * �ͷ�ResultSet����
	 */
	public static void freeResultSet(ResultSet rs) throws SQLException {
		if(rs != null) {
			rs.close();
		}
	}
	
	/*
	 * �ͷ�Statement��PreparedStatement����
	 */
	public static void freeStatement(Statement pstm) throws SQLException {
		if(pstm != null) {
			pstm.close();
		}
	}
	
	/*
	 * �ͷ����Ӷ���
	 */
	public static void freeConnection(Connection conn) throws SQLException {
		if(conn != null) {
			conn.close();
		}
	}
}
