package cn.com.util;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

/*
 * ʵ�ֶ�������ܵ���
 */
public abstract class KeyUtil {
	private KeyUtil() {
		
	}
	/*
	 * ���ܺ���
	 */
	public static String getKey(String msg) {
		String md5Code = null;
		byte[] b = null;
		try {
			b = MessageDigest.getInstance("md5").digest(msg.getBytes());
			
			md5Code = new BigInteger(1,b).toString(16);
			for(int i = 0;i < 32-md5Code.length();i++) {
				md5Code = "0" + md5Code;
			}
			
			
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return md5Code;
	}
	//���Զ�Ӧ�ļ����㷨
	public static void main(String args [])
	{
		int n = 0;
		Scanner scann = new Scanner(System.in);
		n = scann.nextInt();
		while(n>0)
		{
			String a = scann.next();
			System.out.println(KeyUtil.getKey(a));
			n--;
		}
	}
}
