package cn.com.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import cn.com.dao.FoodInfoDAOInf;
import cn.com.db.DBUtil;
import cn.com.pojo.FoodInfo;

/*
 * ʵ�ֶ�ʳ������Ľӿ�
 */
public class FoodInfoDAOImpl implements FoodInfoDAOInf {

	/*
	 * ���ö������鷵�����е�ʳ����Ϣ
	 */
	@Override
	public List<FoodInfo> getAllFoodInfo(Connection conn) throws SQLException {
		// TODO Auto-generated method stub
		List<FoodInfo> list = new ArrayList<FoodInfo>();
		Statement pstm = null;
		ResultSet rs = null;
		FoodInfo fib = null;
		String sql = "select * from goods";
		try {
			pstm = conn.createStatement();
			rs = pstm.executeQuery(sql);
			while(rs.next()) {
				fib = new FoodInfo();
				fib.setgId(rs.getInt("gId"));
				fib.setgName(rs.getString("gName"));
				fib.setShopPrice(rs.getDouble("shopPrice"));
				fib.setImage(rs.getString("image"));
				fib.setDescs(rs.getString("descs"));
				fib.setNumber(rs.getInt("number"));
				fib.setCsid(rs.getInt("csid"));
				fib.setSaleNum(rs.getInt("saleNum"));
				fib.setgState(rs.getInt("gState"));
				fib.setgDate(rs.getString("gDate"));
				
				list.add(fib);
			}
		}finally {
			if(pstm != null) {
				pstm.close();
			}
			if(rs != null) {
				rs.close();
			}
		}
		return list;
	}

	/*
	 * ����ָ��ʳ�����ϸ��Ϣ
	 */
	@Override
	public FoodInfo getFoodInfoById(Connection conn,int foodId) throws SQLException {
		// TODO Auto-generated method stub
		Statement pstm = null;
		ResultSet rs = null;
		FoodInfo fib = null;
		String sql = "select * from goods where gId="+foodId;
		try {
			pstm = conn.createStatement();
			
			rs = pstm.executeQuery(sql);
			if(rs.next()) {
				fib = new FoodInfo();
				fib.setgId(rs.getInt("gId"));
				fib.setgName(rs.getString("gName"));
				fib.setShopPrice(rs.getDouble("shopPrice"));
				fib.setImage(rs.getString("image"));
				fib.setDescs(rs.getString("descs"));
				fib.setNumber(rs.getInt("number"));
				fib.setCsid(rs.getInt("csid"));
				fib.setSaleNum(rs.getInt("saleNum"));
				fib.setgState(rs.getInt("gState"));
				fib.setgDate(rs.getString("gDate"));
	
			}
		}finally {
			if(pstm != null) {
				pstm.close();
			}
			if(rs != null) {
				rs.close();
			}
		}
		return fib;
	}

	/*
	 * ʵ�ֶ�ʳ���޸Ĺ������Ĳ�������������1��
	 */
	@Override
	public boolean changeGoods(Connection conn, int foodId) throws SQLException {
		// TODO Auto-generated method stub
		Statement pstm = null;
		
		FoodInfo fib = null;
		String sql = "update goods set  saleNum = saleNum +1 where gId = "+foodId+"";
		try{
		pstm = conn.createStatement();
			int len = pstm.executeUpdate(sql);
			if(len > 0) {
				DBUtil.freeStatement(pstm);
				return true;
			}
		}catch(SQLException e)
		{
			e.printStackTrace();
			DBUtil.freeStatement(pstm);
			return false;
		}
		DBUtil.freeStatement(pstm);
		return false;
	}


}
