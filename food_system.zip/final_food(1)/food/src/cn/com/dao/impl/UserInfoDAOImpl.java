package cn.com.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.cj.xdevapi.Statement;

import cn.com.dao.UserInfoDAOInf;
import cn.com.db.DBUtil;
import cn.com.pojo.UserInfo;

/*
 * ʵ�ֶ��û������Ľӿ�
 */
public class UserInfoDAOImpl implements UserInfoDAOInf {

	/*
	 * �����û������������ж��Ƿ���ȷ
	 */
	@Override
	public boolean validateByNoAndPwd(Connection conn, int userNo, String userPwd) throws SQLException {
		// TODO Auto-generated method stub
		String sql = "select * from users where uid = ? and password = ?";
		PreparedStatement pstm = null;
		ResultSet rs = null;
		boolean bool = false;
		
		pstm = conn.prepareStatement(sql);
		pstm.setInt(1, userNo);
		pstm.setString(2, userPwd);
		rs = pstm.executeQuery();
		bool = rs.next();
		
		DBUtil.freeResultSet(rs);
		DBUtil.freeStatement(pstm);
		
		return bool;
	}

	/*
	 * �����û������ж��Ƿ���ڸ��û���
	 */
	@Override
	public boolean validateByNo(Connection conn, int userNo) throws SQLException {
		// TODO Auto-generated method stub
		String sql = "select * from users where uid = ?";
		PreparedStatement pstm = null;
		ResultSet rs = null;
		boolean bool = false;
		
		pstm = conn.prepareStatement(sql);
		pstm.setInt(1, userNo);
		rs = pstm.executeQuery();
		bool = rs.next();
		
		DBUtil.freeResultSet(rs);
		DBUtil.freeStatement(pstm);
		
		return bool;
	}

	/*
	 * ���û�ע������Ϣ���뵽���С�
	 */
	@Override
	public boolean insertIntoUsers(Connection conn, UserInfo user1) throws SQLException {
		String sql = "insert into Users values(?,?,?,?,?,?)";
		boolean bool = false;
		PreparedStatement pstm = null;
		pstm = conn.prepareStatement(sql);
		pstm.setInt(1,user1.getUid());
		pstm.setString(2,user1.getUsername());
		pstm.setString(3, user1.getPassword());
		pstm.setString(4, user1.getName());
		pstm.setString(5, user1.getSex());
		pstm.setString(6, user1.getTelephone());
		if(pstm.executeUpdate()>0) bool = true;
		return bool;
	}

	/*
	 * �����û����õ��û�����ϸ��Ϣ
	 */
	@Override
	public UserInfo getUserInfoByNo(Connection conn, int uId) throws SQLException {
		// TODO Auto-generated method stub
		UserInfo user = new UserInfo();
		String sql = "select * from users where uid = ?";
		PreparedStatement pstm = null;
		ResultSet rs = null;
		pstm = conn.prepareStatement(sql);
		pstm.setInt(1, uId);
		rs = pstm.executeQuery();
		if(rs.next())
		{
			user.setUid((rs.getInt("uid")));
			user.setName(rs.getString("name"));
			user.setUsername(rs.getString("username"));
			user.setTelephone(rs.getString("telephone"));
			user.setSex(rs.getString("sex"));
		}
		return user;
	}

	/*
	 * �õ��û�ע���Ժ�Ӧ�÷������û���
	 */
	@Override
	public int getMaxUId(Connection conn) throws SQLException {
		// TODO Auto-generated method stub
		int UId  = 0;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		boolean bool = false;
		//select max(uid) as uid from users;
		String sql = "select * from users order by uid desc limit 1";		
		pstm = conn.prepareStatement(sql);
		rs = pstm.executeQuery();
		if(rs.next()) {
			UId = rs.getInt("uid");
		}
		
		DBUtil.freeResultSet(rs);
		DBUtil.freeStatement(pstm);
		return UId + 1;
	}
	
}
