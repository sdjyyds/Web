package cn.com.dao.impl;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import cn.com.dao.ShoppingCartInf;
import cn.com.db.DBUtil;
import cn.com.pojo.FoodInfo;
import cn.com.pojo.shoppingCartInfo;

/*
 * ʵ�ֹ��ﳵ�����Ľӿ�
 */
public class ShoppingCartInfoImpl implements ShoppingCartInf{

	@Override
	/*
	 * ����Ӧ�Ĺ�����Ϣ���뵽����
	 */
	public boolean insertIntoShoppingCart(Connection conn, shoppingCartInfo shoppingCart) throws SQLException {
		// TODO Auto-generated method stub
		int len = 0;
		PreparedStatement pstm = null;
		String sql = null;
		try{
			sql = "Insert into shopping_cart values(?,?,?,?,?,?)";
			pstm = conn.prepareStatement(sql);
			pstm.setInt(1, shoppingCart.getCtId());
			pstm.setInt(2, shoppingCart.getuId());
			pstm.setInt(3, shoppingCart.getgId());
			pstm.setInt(4, shoppingCart.getgNum());
			pstm.setString(5,shoppingCart.getSpecif());
			pstm.setString(6, shoppingCart.getCtTime());
			
			len = pstm.executeUpdate();
				if(len > 0) {
					DBUtil.freeStatement(pstm);
					return true;
				}
			}catch(SQLException e)
			{
				e.printStackTrace();
				DBUtil.freeStatement(pstm);
				return false;
			}
			DBUtil.freeStatement(pstm);
			return false;
	}

	/*
	 * �õ���ȷ�Ĺ��ﳵid��ʵ���Ƿ񴴽��µĹ��ﳵ
	 */
	@Override
	public int getTrueShoppingCart(Connection conn,int uId,int gId) throws SQLException {
		// TODO Auto-generated method stub
		Statement stmt = null;
		String sql = null;
		ResultSet rs = null;
		int ctId = -1;
		ctId = getExistShoppingCart(conn,uId,gId); 
		return ctId;
	}
	
	/*
	 * �õ����в����ڵĹ��ﳵid�����������µĹ��ﳵ��׼��
	 */
	public int getMaxctId(Connection conn) throws SQLException
	{
		Statement stmt = null;
		String sql = null;
		ResultSet rs = null;
		int ctId = -1;
		stmt = conn.createStatement();
		sql ="SELECT MAX(ctId) AS ctId FROM shopping_cart;";
		rs = stmt.executeQuery(sql);
		if(rs.next()){
			ctId = rs.getInt("ctId") + 1;
		}
		DBUtil.freeStatement(stmt);
		return ctId;
	}
	
	/*
	 *����ʳƷid���û���id����ѯ�Ƿ���ڸù��ﳵid 
	 */
	public int getExistShoppingCart(Connection conn,int uId,int gId) throws SQLException
	{
		PreparedStatement pstm = null;
		ResultSet rs = null;
		int ctId = -1;
		String sql = "select * from shopping_cart where uId = ? and gId = ?";
		pstm = conn.prepareStatement(sql);
		pstm.setInt(1, uId);
		pstm.setInt(2, gId);
		rs = pstm.executeQuery();
		if(rs.next()) ctId = rs.getInt("ctId");
		DBUtil.freeStatement(pstm);
		return ctId;
	}
	
	/*
	 * �����˶�Ӧ�Ĺ��ﳵid����������+1
	 */
	public boolean changeShoppingCart(Connection conn,int ctId) throws SQLException
	{
		PreparedStatement pstm = null;
		String sql = "update shopping_cart set gNum = gNum + 1 where ctId = ?";
		pstm = conn.prepareStatement(sql);
		pstm.setInt(1,ctId);
		pstm.executeUpdate();
		return true;
	}

	/*
	 * �����û����õ����û������еĹ��ﳵ��Ϣ���洢���������С�
	 */
	@Override
	public List<shoppingCartInfo> getAllshoppingCartInfo(Connection conn, int uId) throws SQLException {
	    // ����һ�� List ���洢��� shoppingCartInfo ����
	    List<shoppingCartInfo> shoppingCartList = new ArrayList<>();
	    Statement pstm = null;
	    ResultSet rs = null;
	    
	    String sql = "select * from shopping_cart where uId="+uId ;
	    try {
	        pstm = conn.createStatement();
	        rs = pstm.executeQuery(sql);
	        
	        while (rs.next()) {
	            shoppingCartInfo fib = new shoppingCartInfo(); // ��ѭ���ڴ��� shoppingCartInfo ����
	            fib.setgId(rs.getInt("gId"));
	            fib.setuId(rs.getInt("uId"));
	            fib.setgNum(rs.getInt("gNum"));
	            
	            // ��ÿ�ε����� shoppingCartInfo �������ӵ��б���
	            shoppingCartList.add(fib);
	        }
	    } finally {
	        // �ر���Դ
	        if (pstm != null) {
	            pstm.close();
	        }
	        if (rs != null) {
	            rs.close();
	        }
	    }
	    
	    return shoppingCartList; // ���ش洢�˶�� shoppingCartInfo ������б�
	}

}
























